#!/usr/bin/env bash

for file in $(find . -name "config.toml"); do
    perl -pi -e 's/(timeout_propose = )".*"/$1"9s"/' $file
    perl -pi -e 's/(timeout_propose_delta = )".*"/$1"1500ms"/' $file
    perl -pi -e 's/(timeout_prevote = )".*"/$1"3s"/' $file
    perl -pi -e 's/(timeout_prevote_delta = )".*"/$1"1500ms"/' $file
    perl -pi -e 's/(timeout_precommit = )".*"/$1"3s"/' $file
    perl -pi -e 's/(timeout_precommit_delta = )".*"/$1"1500ms"/' $file
    perl -pi -e 's/(timeout_commit = )".*"/$1"3s"/' $file
done
